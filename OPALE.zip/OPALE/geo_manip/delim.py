#!/usr/local/bin/python
# coding: latin-1
################################################################################

#*******************************************************************************
#                              TIP TOP                                  
#                    DELIMITATION DU BASSIN VERSANT                 
#                        TIPTOP-delim.py                                 
#*******************************************************************************
#                              Author                    
#                      Dominique Trevisan
#                       INRA UMR Carrtel
#                dominique.trevisan@inra.fr              
#                        15 sep 2018                  
################################################################################









import glob, sys, os, string, time, math
import subprocess
from qgis.core import*
import qgis.utils
import qgis.gui
from qgis.utils import iface
from osgeo import gdal
import processing
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtCore import QFileInfo
from PyQt4.QtCore import QVariant
from sys import argv
import os.path
from PyQt4.QtGui import QProgressDialog, QProgressBar
from os import listdir

dialog=QFileDialog()
qid = QInputDialog()
canvas = iface.mapCanvas()


inputfolder = dialog.getExistingDirectory(None,'Selectionnez Dossier MNT')
outputfolder=dialog.getExistingDirectory(None,'Selectionnez Dossier resultats')
river_file=dialog.getOpenFileName(None, 'Selectionnez shape rivières','c:\\',"Shape file (*.shp)")
sol=dialog.getOpenFileName(None, 'Selectionnez shape sols','c:\\',"Shape file (*.shp)")
print 'load maps'


input, ok = QInputDialog.getText( qid, "Enter Outlet Coordinates", "Enter New Coordinates as 'xcoord,ycoord'", QLineEdit.Normal, "X" + "," + "Y")
if ok:
    x = input.split( "," )[ 0 ]
    #print x
    y = input.split( "," )[ 1 ]
    #print y
    if not x:
        print "Ooops!X value is missing!"
    if not y:
        print "Ooops!Y value is missing!"
    print x + "," + y
    scale=50
    rect = QgsRectangle(float(x)-scale,float(y)-scale,float(x)+scale,float(y)+scale)
    canvas.setExtent(rect)
    pt = QgsPoint(float(x),float(y))
    canvas.refresh()

cooX=x.encode("ascii")
cooX=float(cooX)
cooY=y.encode("ascii")
cooY=float(cooY)
coordinates=x+','+y
coordi = coordinates.encode("ascii")

input, ok = QInputDialog.getText( qid, "Soil", "Enter Name of soil units attribute (string)")
if ok:
    attr = input
        #print y
    if not attr:
        print "Ooops!X value is missing!"
    print 'soil unit attribute: ' +attr
    canvas.refresh()

attrib=attr.encode("ascii")

input, ok = QInputDialog.getText( qid, "river order", "Enter Name of river order attribute (string)")
if ok:
    attr = input
        #print y
    if not attr:
        print "Ooops!X value is missing!"
    print 'river order: ' +attr
    canvas.refresh()

attrib_river=attr.encode("ascii")

#fix EPSG to Lambert 93

canvas.mapRenderer().setProjectionsEnabled(True)
canvas.mapRenderer().setDestinationCrs(QgsCoordinateReferenceSystem("EPSG:2154"))
test=os.listdir(inputfolder)
for item in test:
    if item.endswith(".xml"):
        os.remove(inputfolder+'\\'+item)


print'input DEM'
dalle=outputfolder+'\\dalle.tif'


test=os.listdir(inputfolder)
i=0
list_dir=""
for raster in glob.glob(inputfolder+'\\*.asc'):
    fileInfo=QFileInfo(raster)
    baseName = fileInfo.baseName()
    rlayer = QgsRasterLayer(raster, baseName)
    extent = rlayer.extent()
    xmin = extent.xMinimum()
    xmax = extent.xMaximum()
    ymin = extent.yMinimum()
    ymax = extent.yMaximum()
    i=i+1
    f_out=outputfolder+'\\'+'dalle'+str(i)+'.tif'
    outputs_GDALOGRTRANSLATE_1=processing.runalg('gdalogr:translate', rlayer,100.0,True,'0',0,'EPSG:2154',"%f,%f,%f,%f"% (xmin, xmax, ymin, ymax),False,5,4,75.0,6.0,1.0,False,0,False,None,f_out)
    iface.addRasterLayer(f_out, 'dalle'+str(i))
    list_dir=list_dir+';'+f_out
print'merge dem'

list_dir=list_dir[1:]
dalle_tot=outputfolder+'\\dalle_tot.tif'

outputs_GDALOGRMERGE_1=processing.runalg('gdalogr:merge', list_dir,False,False,5,dalle_tot)
layer=iface.addRasterLayer(dalle_tot, 'dalle_tot')
e = layer.extent()
etendue = str(e.xMinimum()) + ","+str(e.xMaximum())+","+str(e.yMinimum())+","+str(e.yMaximum())
outputs_GDALORGRASTERINFO_1=processing.runalg('gdalorg:rasterinfo', dalle_tot,False,False,None)
res=open(outputs_GDALORGRASTERINFO_1['OUTPUT'],'r+')
res_str=res.read()
a=res_str.find('Pixel Size')
res_str=res_str[a:]
a=res_str.find('(')
b=res_str.find(',')
res_str=res_str[a+1:b]
print res_str
dem=outputfolder+'\\dalle_tot.tif'
out=outputfolder+'\\burned_dem.tif'

def transl(dalle, file2):
    rast_dalle = gdal.Open(dalle, 1)
    rast_file2 = gdal.Open(file2, 1)
    # Get affine transform coefficients
    gt_dalle = rast_dalle.GetGeoTransform()
    gt_file2 = rast_file2.GetGeoTransform()
    # Convert tuple to list, so we can modify it
    gtl_dalle = list(gt_dalle)
    gtl_file2 = list(gt_file2)
    diff0=gtl_dalle[0]-gtl_file2[0]
    diff3=gtl_dalle[3]-gtl_file2[3]
    gtl_file2[0] = gtl_file2[0]+diff0
    gtl_file2[3] = gtl_file2[3]+diff3
    # Save the geotransform to the raster
    rast_file2.SetGeoTransform(tuple(gtl_file2))
    rast_file2 = None#equivalent to close
    rast_dalle= None
    
outputs_CARVE_1=processing.runalg('grass7:r.carve', dem,river_file,res_str,10.0,True,etendue,0.0,-1.0,0.0001,0,out,None)

transl(dalle_tot, out)
iface.addRasterLayer(out, 'dem_burned')



dem=outputfolder+'\\burned_dem.tif'
dem_f=outputfolder+'\\burned_dem_fill.tif'
prob=outputfolder+'\\prob.tif'
k=1
while k==1:
    outputs_FILL=processing.runalg('grass7:r.fill.dir', dem,0,etendue,res_str,dem_f,None,prob)
    transl(dalle_tot,dem_f)
    out_st=outputfolder+'\\stat.html'
    outputs_STATISTICS=processing.runalg('qgis:rasterlayerstatistics', prob,out_st)
    res=open(out_st,'r+')
    ras_stat=res.read()
    a=ras_stat.find('Maximum value')
    ras_stat=ras_stat[a+14:]
    a=ras_stat.find('<')
    ras_stat=ras_stat[:a]
    print ras_stat+' unresolved areas'
    dem=dem_f
    if int(ras_stat)==0:
        k=0
print 'calc watershed'
out_acc=outputfolder+'\\out_acc.tif'
drain=outputfolder+'\\drain.tif'
fileName = dem
fileInfo = QFileInfo(fileName)
baseName = fileInfo.baseName()
rlayer = QgsRasterLayer(fileName, baseName)
extent = rlayer.extent()
xmin = extent.xMinimum()
xmax = extent.xMaximum()
ymin = extent.yMinimum()
ymax = extent.yMaximum()
processing.runalg("grass7:r.watershed", dem, None, None, None, None, 10, 0, 1, \
300, False, True, False, False, False,"%f,%f,%f,%f"% (xmin, xmax, ymin, ymax), \
res_str, out_acc,drain, None, None, None, None, None, None)

transl(dalle_tot,drain)
transl(dalle_tot,out_acc)

iface.addRasterLayer(drain, 'drain')
lyr=iface.addRasterLayer(out_acc, 'acc')

print 'search max acc'
def cal_acc(lyr,X,Y,a,b):
    X=X+a
    Y=Y+b
    ident = lyr.dataProvider().identify(QgsPoint(X,Y), QgsRaster.IdentifyFormatValue)
    accum=ident.results()
    acc=accum[1]
    return acc, X,Y
max_acc=cal_acc(lyr,cooX,cooY,0,0)
print max_acc[0]
flres=float(res_str)
sqres=flres*math.sqrt(2)
#first ring
#West
acc=cal_acc(lyr,cooX,cooY,-flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#NW
acc=cal_acc(lyr,cooX,cooY,-sqres,sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#N
acc=cal_acc(lyr,cooX,cooY,0,flres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#NE
acc=cal_acc(lyr,cooX,cooY,sqres,sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#E
acc=cal_acc(lyr,cooX,cooY,flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#SE
acc=cal_acc(lyr,cooX,cooY,sqres,-sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#S
acc=cal_acc(lyr,cooX,cooY,-flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#SW
acc=cal_acc(lyr,cooX,cooY,-sqres,-sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
    
#second ring
flres=2*float(res_str)
sqres=2*flres*math.sqrt(2)

#West
acc=cal_acc(lyr,cooX,cooY,-flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#NW
acc=cal_acc(lyr,cooX,cooY,-sqres,sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#N
acc=cal_acc(lyr,cooX,cooY,0,flres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#NE
acc=cal_acc(lyr,cooX,cooY,sqres,sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#E
acc=cal_acc(lyr,cooX,cooY,flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#SE
acc=cal_acc(lyr,cooX,cooY,sqres,-sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#S
acc=cal_acc(lyr,cooX,cooY,-flres,0)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc
#SW
acc=cal_acc(lyr,cooX,cooY,-sqres,-sqres)
print acc[0]
if acc[0]>max_acc[0]:
    max_acc=acc

coordi_new=str(max_acc[1])+','+str(max_acc[2])
out=outputfolder+'\\bvOK.tif'
outputs_WATER_OUTLET=processing.runalg('grass7:r.water.outlet', drain,coordi_new,etendue,res_str,out)
#translate BV_OK rast
transl(dalle_tot,out)
iface.addRasterLayer(out, 'bv')
#set -9999 to nodata_value
outputs_RECLAS=processing.runalg('saga:reclassifygridvalues', \
out,0,0.0,1.0,0,0.0,1.0,2.0,0,'0,0,0,0,0,0,0,0,0',0,True,-9999.0,True,0.2,None)

out_vec=outputfolder+'\\limiteBV.shp'
GDAL_POLY=processing.runalg("gdalogr:polygonize",out,"ind",None)

layer = QgsVectorLayer(GDAL_POLY['OUTPUT'], "Limite_bv", "ogr")
crs = layer.crs()
crs.createFromId(2154)
layer.setCrs(crs)
e = layer.extent()
etendue_lim = str(e.xMinimum()) + ","+str(e.xMaximum())+","+str(e.yMinimum())+","+str(e.yMaximum())
writer = QgsVectorFileWriter.writeAsVectorFormat(layer,out_vec,"utf-8",None,"ESRI Shapefile")
layer = QgsVectorLayer(out_vec, "Limite_bv", "ogr")
QgsMapLayerRegistry.instance().addMapLayer(layer)
# fill dem
print 'fill dem'
dem=outputfolder+'\\dalle_tot.tif'
dem_f=outputfolder+'\\dem_filled.tif'
prob=outputfolder+'\\prob.tif'
k=1
while k==1:
    outputs_FILL=processing.runalg('grass7:r.fill.dir', dem,0,etendue,res_str,dem_f,None,prob)
    transl(dalle_tot,dem_f)
    out_st=outputfolder+'\\stat.html'
    outputs_STATISTICS=processing.runalg('qgis:rasterlayerstatistics', prob,out_st)
    res=open(out_st,'r+')
    ras_stat=res.read()
    a=ras_stat.find('Maximum value')
    ras_stat=ras_stat[a+14:]
    a=ras_stat.find('<')
    ras_stat=ras_stat[:a]
    print ras_stat+' unresolved areas'
    dem=dem_f
    if int(ras_stat)==0:
        k=0


print 'generate mnt.asc'
mnt=dem_f
output_GDAL_TRANS=processing.runalg('gdalogr:translate',mnt,100.0,True,None,0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
output_GDAL_CLIP=processing.runalg('gdalogr:cliprasterbymasklayer', output_GDAL_TRANS['OUTPUT'],out_vec,'-9999',False,False,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
out_asc=outputfolder+'\\mnt_decoupe.asc'
output_GDAL_TRANS=processing.runalg('gdalogr:translate',output_GDAL_CLIP['OUTPUT'],100.0,True,'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,out_asc)
slope=outputfolder+'\\slope.tif'
SLOPE=processing.runalg('gdalogr:slope', output_GDAL_CLIP['OUTPUT'],1.0,True,False,True,1.0,slope)
print 'generate bv.asc'
specific_sto_rast = outputs_RECLAS['RESULT']

output_GDAL_TRANS=processing.runalg('gdalogr:translate',specific_sto_rast,100.0,True,\
'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,None)

out_asc=outputfolder+'\\specific_sto.asc'

output_GDAL_TRANS=processing.runalg('gdalogr:translate',output_GDAL_TRANS['OUTPUT'], \
100.0,True,'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,out_asc)

print 'generate river.asc'
out_asc = outputfolder+"\\"+"riv.asc"
output_VtoR=processing.runalg('saga:shapestogrid',river_file,attrib_river,2,4,0,0,2,etendue_lim,res_str,0,None)
output_GDAL_TRANS=processing.runalg('gdalogr:translate',output_VtoR['GRID'],100.0,True,None,0,'',\
etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
output_GDAL_CLIP=processing.runalg('gdalogr:cliprasterbymasklayer', output_GDAL_TRANS['OUTPUT'],out_vec,'-9999',\
False,False,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
iface.addRasterLayer(output_VtoR['GRID'], 'river_rasterized')
rast_file = gdal.Open(output_GDAL_CLIP['OUTPUT'], 1)
gt_file = rast_file.GetGeoTransform()
gtl_file = list(gt_file)
diff0=e.xMinimum()-gtl_file[0]
diff3=e.yMaximum()-gtl_file[3]
gtl_file[0] = gtl_file[0]-diff0
gtl_file[3] = gtl_file[3]-diff3
rast_file.SetGeoTransform(tuple(gtl_file))
rast_file = None
output_GDAL_TRANS=processing.runalg('gdalogr:translate',output_GDAL_CLIP['OUTPUT'],100.0,\
True,'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,out_asc)




out_rast_calc=outputfolder+"\\"+"riv_1.tif"
out_riv_slope=outputfolder+"\\"+"riv_slopes.tif"
SAGARASTCALC=processing.runalg('saga:rastercalculator', out_asc,[],'(a>0)/(a>0)',False,7,out_rast_calc)
SAGAGRIDSPRODUCT=processing.runalg('saga:gridsproduct', [out_rast_calc,slope],None)
SAGARASTCALC=processing.runalg('saga:rastercalculator', SAGAGRIDSPRODUCT['RESULT'],[],'a/100',False,7,out_riv_slope)

#transl(dalle_tot,output_VtoR['GRID'])

iface.addRasterLayer(out_riv_slope,'river_slope')
out_asc = outputfolder+"\\"+"riv_slope.asc"
output_GDAL_TRANS=processing.runalg('gdalogr:translate',out_riv_slope,100.0,\
True,'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,out_asc)

print 'generate sol.asc'
out_sol = outputfolder+"\\"+"sol.asc"
out_ATTRIB=processing.runalg('saga:shapestogrid',sol,attrib,2,4,0,0,2,etendue_lim,res_str,0,None)
iface.addRasterLayer(out_ATTRIB['GRID'], 'rasterized')


#output_GDAL_TRANS=processing.runalg('gdalogr:translate',out_ATTRIB['GRID'],100.0,True,None,0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
output_GDAL_CLIP=processing.runalg('gdalogr:cliprasterbymasklayer', out_ATTRIB['GRID'],out_vec,'-9999',False,False,False,5,4,75.0,6.0,1.0,False,0,False,None,None)
#update minimim:maximm
rast_file = gdal.Open(output_GDAL_CLIP['OUTPUT'], 1)
gt_file = rast_file.GetGeoTransform()
gtl_file = list(gt_file)
diff0=e.xMinimum()-gtl_file[0]
diff3=e.yMaximum()-gtl_file[3]
gtl_file[0] = gtl_file[0]-diff0
gtl_file[3] = gtl_file[3]-diff3
rast_file.SetGeoTransform(tuple(gtl_file))
rast_file = None


output_GDAL_TRANS=processing.runalg('gdalogr:translate',output_GDAL_CLIP['OUTPUT'],100.0,True,'-9999',0,'',etendue_lim,False,5,4,75.0,6.0,1.0,False,0,False,None,out_sol)
print 'COMPLETED'